    #include <stdio.h>
    #include <stdlib.h>
    #include <string.h>
    #include <unistd.h>
    #include <arpa/inet.h>
    #include <sys/socket.h>
    #include <sys/time.h>
    #include <sys/stat.h>
    #include <sys/select.h>
    #include <errno.h>

    #define BUF_SIZE 1024
    #define MAX_CONN 10
    //To specify MSG type
    #define HANDSHAKE 1 // To request handshake
    #define OFFSET 2 // File Offset That we should reupload.
    #define DATA 3 // Transfer real data
    #define FIN 4 // To close connection

    void error_handling(char *message);

    #pragma pack(1) // we should use pragma padding bit reference:https://blog.naver.com/chldpfka33/222163683544
    typedef struct{ // Total header : 45byte
    char client_id[32]; // Unique Client ID[32byte](for resuming uploads)
    uint64_t offset; // To notify present file uploading sequence[8byte]
    uint32_t payload_len; // Length of the payload in bytes[4byte]
    uint8_t type; // Type of the message[1byte]
    } packet_h;
    


    int main(int argc, char *argv[])
    {
        int serv_sock, clnt_sock;
        struct sockaddr_in serv_adr, clnt_adr;
        struct timeval timeout;
        fd_set reads, cpy_reads;
        socklen_t adr_sz;
        int fd_max, fd_num, i;
        char buf[BUF_SIZE];
        
        char file_name[MAX_CONN][BUF_SIZE];
        FILE *fp[MAX_CONN];
        int read_first[MAX_CONN];
        int read_offset[MAX_CONN];  
        
        if (argc != 2) {
            printf("Usage : %s <port>\n", argv[0]);
            exit(1);
        }
        //socket()
        serv_sock = socket(PF_INET, SOCK_STREAM, 0);
        
        // To reuse port to use SO_REUSEADDR then we can connect no latency.
        int opt = 1;
        setsockopt(serv_sock, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt));
        
        memset(&serv_adr, 0, sizeof(serv_adr));
        serv_adr.sin_family = AF_INET;
        serv_adr.sin_addr.s_addr = htonl(INADDR_ANY);
        serv_adr.sin_port = htons(atoi(argv[1]));
        //bind()
        if (bind(serv_sock, (struct sockaddr*)&serv_adr, sizeof(serv_adr)) == -1)
            error_handling("bind() error");
        //listen()
        if (listen(serv_sock, 5) == -1)
            error_handling("listen() error");

        // TODO: init descriptor 
        FD_ZERO(&reads);
        FD_SET(serv_sock, &reads);
        fd_max = serv_sock;
            
        for (i = 0; i < MAX_CONN; i++){
            read_first[i] = 1;  
            read_offset[i] = 0;
            fp[i] = NULL;
            memset(file_name[i], 0, BUF_SIZE);
        }

        while (1){
            cpy_reads = reads;
            // TODO: set timer
            timeout.tv_sec = 5;
            timeout.tv_usec = 5000;
            
            // TODO: select()
            if ((fd_num = select(fd_max+1, &cpy_reads, 0, 0, &timeout)) == -1){
                error_handling("select() error");
                break;
            }
            if (fd_num == 0) continue; 
        for (i = 0; i < fd_max + 1; i++)
            {
                if (FD_ISSET(i, &cpy_reads))// TODO: check file descriptor
                {
                    if (i == serv_sock)      // connection request! 
                    {
                        // TODO: when connecion request 
                        adr_sz = sizeof(clnt_adr);
                        clnt_sock = accept(serv_sock, (struct sockaddr*)&clnt_adr, &adr_sz);
                        if(fd_max < clnt_sock) fd_max = clnt_sock;
                        FD_SET(clnt_sock, &reads);


                        fp[clnt_sock] = NULL;
                        read_offset[clnt_sock] = 0;
                        read_first[clnt_sock] = 1;
                        memset(file_name[clnt_sock], 0, BUF_SIZE);

                        printf("connected...");
                        printf("Connected client IP(%d): %s \n", i, inet_ntoa(clnt_adr.sin_addr)); 
                    }
                    else // Data recieve 
                    {
                        packet_h header;
                        int total_read = 0;
                        int read_len = 0;           
                        // Loop until read header size
                        while(total_read < sizeof(header)) 
                        {
                            read_len = read(i, (char*)&header+total_read, sizeof(header) - total_read);

                            if (read_len <= 0) // if Disconnected then close the socket
                            {
                                FD_CLR(i, &reads);
                                close(i);
                                printf("Closed client: %d \n", i);
                                read_first[i] = 1;
                                read_offset[i] = 0;
                                if (fp[i] != NULL) { fclose(fp[i]); fp[i] = NULL; } 
                                break;
                            }
                            total_read += read_len;
                        }
                        if (read_len <= 0){
                            FD_CLR(i, &reads); 
                            close(i);
                            continue;
                        }

                        if (read_first[i]) // if first request (Handshake)
                        {
                        if (header.type != HANDSHAKE) {
                            FD_CLR(i, &reads);
                            close(i);
                            printf("handkshake error, Closed client: %d \n", i);    
                            continue;
                        }  

                        // To read file_name
                        total_read = 0;
                        while(total_read < header.payload_len)
                        {
                        read_len = read(i, file_name[i] + total_read, header.payload_len - total_read);
                        if (read_len <= 0){
                            FD_CLR(i, &reads);
                            close(i);
                            printf("Closed client: %d \n", i);
                            read_first[i] = 1;
                            read_offset[i] = 0; 
                            break;
                        }
                        total_read += read_len;
                        }
    
                            
                        // prevent overflow
                        file_name[i][header.payload_len] = '\0'; 
                        // make directory with client id
                        mkdir(header.client_id, 0777);

                        char full_path[BUF_SIZE + 64];
                        snprintf(full_path, sizeof(full_path), "%s/%s", header.client_id, file_name[i]);
                        struct stat st;
                        if(stat(full_path, &st) == 0) // if File exist, then fopen() with "ab"
                        {
                            read_offset[i] = st.st_size; 
                            fp[i] = fopen(full_path, "ab");
                            printf("Resume uploading: %s from %d\n", file_name[i], read_offset[i]);
                        } 
                        else
                        { // File dosen't exists. Make new File.
                            read_offset[i] = 0;
                            fp[i] = fopen(full_path, "wb");
                            printf("New file uploading: %s\n", file_name[i]);
                        }   

                        if (fp[i] == NULL){ //
                            FD_CLR(i, &reads);
                            close(i);
                            printf("File Open Error, Closed client: %d \n", i);
                            read_first[i] = 1;
                            read_offset[i] = 0; 
                            continue;
                        }
                        
                        // Send file offset to clients 
                        packet_h response;
                        memset(&response, 0, sizeof(response));
                        response.type = OFFSET; 
                        response.offset = read_offset[i];
                        response.payload_len = 0;
                                    
                        write(i, &response, sizeof(response)); // send header 
                        read_first[i] = 0; 
                        }
                        else // Not Handshake (header type is DATA or FIN)
                        {
                            if (header.type == FIN) // Fin
                                {
                                printf("File recive completed: %s \n", file_name[i]);
                                write(i, "Successed!", 11); // Ack
                                
                                if (fp[i] != NULL) { 
                                    fclose(fp[i]); fp[i] = NULL;
                                }
                                // close socket
                                FD_CLR(i, &reads);
                                close(i);
                                printf("Closed client: %d \n", i);
                                read_first[i] = 1;
                                read_offset[i] = 0; 
                            }
                            else if (header.type == DATA) // header type is DATA
                            {
                                // check order read_offset and header.offset  
                                if (header.offset != read_offset[i]) 
                                {   
                                    // Does not match in order, packet abandoned
                                    int to_skip = header.payload_len;
                                    while (to_skip > 0) {
                                        int r = read(i, buf, (to_skip > BUF_SIZE) ? BUF_SIZE : to_skip);
                                        if (r <= 0) break;
                                        to_skip -= r;
                                    }
                                    continue; // wait next packet
                                }

                                // receive DATA 
                                int left_len = header.payload_len; // left bytes to read
                                
                                while (left_len > 0) 
                                {
                                    // if left to read > BUF_SIZE, then read size is BUF_SIZE, if not then left_len
                                    int r_len = read(i, buf, (left_len > BUF_SIZE) ? BUF_SIZE : left_len);
                                    if (r_len <= 0) {
                                        // close the connection
                                        FD_CLR(i, &reads);
                                        close(i);
                                        printf("Client %d disconnected during transfer\n", i);
                                        if (fp[i] != NULL) { 
                                            fclose(fp[i]); 
                                            fp[i] = NULL;
                                            }
                                        read_first[i] = 1;
                                        read_offset[i] = 0;
                                        break; 
                                    }

                                    fwrite(buf, 1, r_len, fp[i]);
                                    read_offset[i] += r_len; // update read_offset
                                    left_len -= r_len;       
                                }
                            }
                        }
                    } 
                }  
            }
        }

        close(serv_sock);
        return 0;
    }

    void error_handling(char *message)
    {
        fputs(message, stderr);
        fputc('\n', stderr);
        exit(1);
    } 