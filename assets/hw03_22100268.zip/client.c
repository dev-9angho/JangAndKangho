#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <stdbool.h>
#define BUF_SIZE 1024
//To specify MSG type
#define HANDSHAKE 1 // To requeset handshake
#define OFFSET 2 // File Offset That we should reupload.
#define DATA 3 // Transfer real data 
#define FIN 4 // To close connection


#pragma pack(1) // we should use pragma padding bit reference:https://blog.naver.com/chldpfka33/222163683544
typedef struct{ // Total header : 45byte 
char client_id[32]; // Unique Client ID[32byte] (for resuming uploads)
uint64_t offset; // To notify present file uploading sequence[8byte]
uint32_t payload_len; // Length of the payload in bytes[4byte]
uint8_t type; // Type of the message[1byte]
} packet_h;


void error_handling(char *message);

int main(int argc, char *argv[])
{
   int sd;
   FILE *fp;
   
   char file_name[BUF_SIZE];
   char buf[BUF_SIZE];
   int read_cnt;
   
   struct sockaddr_in serv_adr;
  packet_h header;
   packet_h response_header;
   int progress_offset =0;
   

   if (argc != 5) {
      printf("Usage: %s <IP> <port> <Client ID> <file name> \n", argv[0]);
      exit(1);
   }

   struct stat st;  //  Check file exists
   if(stat(argv[4], &st) == -1){
      error_handling("File not found");
   }

   fp = fopen(argv[4], "rb");

   int upload_completed = 0;

   while(!upload_completed){
   // make new socket in every sequnece 
      sd = socket(PF_INET, SOCK_STREAM, 0);
      if(sd == -1){
         printf("socket() error");
         continue;
      }

      memset(&serv_adr, 0, sizeof(serv_adr));
      serv_adr.sin_family = AF_INET;
      serv_adr.sin_addr.s_addr = inet_addr(argv[1]);
      serv_adr.sin_port = htons(atoi(argv[2]));
      // strcpy(&client_id, argv[3])
      snprintf(file_name, sizeof(file_name), "%s", argv[4]);
      
   // connect
       //   If connect fail, then reconnect(◼ Connection reset)
      if (connect(sd, (struct sockaddr*)&serv_adr, sizeof(serv_adr)) == -1) {
         printf("connect() error\n");
         close(sd);
         sleep(2);
         continue;
   }
      

   
   // Send handshake with file name 
   memset(&header, 0, sizeof(header));
   header.type = HANDSHAKE;
   header.offset = 0;
   strncpy(header.client_id, argv[3], sizeof(header.client_id));
   header.payload_len = strlen(file_name);
   // send header
   
   if(write(sd, &header, sizeof(header)) == -1){
      // ◼ write() failure
         close(sd);
         sleep(2);
         printf("write() error at sending header.\n");
         continue;
   }
 
   if(write(sd, file_name, header.payload_len) == -1){
      // ◼ write() failure
         close(sd);
         sleep(2);
         printf("write() error at sending file_name");
         continue;
   }
   

   // To recieve file offset (waiting send file offset from server)
   int read_offset = read(sd, &response_header, sizeof(response_header));
   if(read_offset == -1){
      // ◼ read() failure
      close(sd);
      sleep(2);
      printf("read() error at recieve file offset");
      continue; // Loop again 
   }   else if(read_offset == 0){
      // ◼ peer closed connection (like read() == 0) 
         printf("server closed socket normally. close the Socket...\n");
         close(sd);
         sleep(2);
         break;
   }

   // if responsed header is OFFSET 
   if(response_header.type == OFFSET){
      progress_offset = response_header.offset;
      
      if(progress_offset >= st.st_size){
         printf("all file upload completed!\n");
         upload_completed = 1;
         close(sd);
         break;
      }

      if(fseek(fp, progress_offset, SEEK_SET) != 0){
         printf("fseek() error");
         close(sd);
         break;
      }
   }
   else{
      printf("Unexpected header type. retry...");
      close(sd);
      sleep(2);
      continue;
   }

   printf("Data transfer started from offset %d\n", progress_offset);

   //  Looping until upload completed.
   int error = 0;
   while(!feof(fp)){   
   // Send file data 
      read_cnt = fread((void*)buf, 1, BUF_SIZE, fp);
      if(read_cnt > 0){
         // set header 
         memset(&header, 0, sizeof(header));
         header.type = DATA;
         header.offset = progress_offset;
         header.payload_len = read_cnt;
         // write header and buf
         if(write(sd, &header, sizeof(header)) < 0) {
            // ◼ write() failure
            error = 1;
            printf("write() error at sending DATA header.");
            break;
         }
         if(write(sd, buf, read_cnt) < 0) {
            // ◼ write() failure
            error = 1;
            printf("write() error at sending file data.");
            break;
         }
         progress_offset += read_cnt;
      }
   }
      
      if(error){ //if error detected, close the socket and back again.
         close(sd);
         sleep(2);
         continue;
      }

      //just send header type FIN
      if(feof(fp) && !error){
      printf("Transfer finished. Sending FIN...\n");
      // FIN
      memset(&header, 0, sizeof(header));
      header.type = FIN;
      header.offset = progress_offset;
      header.payload_len = 0;
      // send FIN to server
      write(sd, &header, sizeof(header));
      // read ACK from server 
      read(sd, buf, BUF_SIZE);
      printf("successly uploaded!\n");
      upload_completed = 1;
      }
   close(sd);
   }
   fclose(fp);
   return 0;
}
   


void error_handling(char *message)
{
   fputs(message, stderr);
   fputc('\n', stderr);
   exit(1);
}